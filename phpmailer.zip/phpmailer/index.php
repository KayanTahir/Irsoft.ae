<?php 
require 'include/PHPMailer.php';
require 'include/SMTP.php';
require 'include/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

 $mail = new PHPMailer();
 $mail ->isSMTP();
 $mail->Host = "mail.irsoft.ae";
 $mail->SMTPAuth = "true";
 $mail->SMTPSecure = "tls";
 $mail->Port = 465;
 $mail->username = "irnm@irsoft.ae";
 $mail->Password = "Irnm2016ir!";
 $mail->Subject = "Helloworld";
 $mail->setFrom("irnm@irsoft.ae");
 $mail->Body = "This is testing 123";
 $mail->addAddress("irnm@irsoft.ae");
 

if ($mail->Send()) {
	echo "Email Success";
}else{
	echo "Not send";
}

 $mail->smtpClose();

?>